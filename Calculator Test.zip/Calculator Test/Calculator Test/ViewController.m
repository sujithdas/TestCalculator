//
//  ViewController.m
//  Calculator Test
//
//  Created by sujith das on 11/07/13.
//  Copyright (c) 2013 Sujith das. All rights reserved.
//

#import "ViewController.h"
#import <FacebookSDK/FacebookSDK.h>
@interface ViewController ()

@end

@implementation ViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
  
        share.enabled = NO; //Share Button disabling before the result is displayed
      HUD = [[MBProgressHUD alloc] initWithView:self.view];//Progress HUD
}

- (void)viewWillDisappear:(BOOL)animated
{
  [self dealloacHUD];
}


#pragma Clear Text Fields methods
- (IBAction) clearDisplay {
    displayField.text = @"";
}

#pragma Actions for Buttons 0-9

- (IBAction) button0{
     displayField.text=[NSString stringWithFormat:@"%@0",displayField.text];
}
- (IBAction) button1{
    displayField.text=[NSString stringWithFormat:@"%@1",displayField.text];
}
- (IBAction) button2{
    displayField.text=[NSString stringWithFormat:@"%@2",displayField.text];

}
- (IBAction) button3{
     displayField.text=[NSString stringWithFormat:@"%@3",displayField.text];
}
- (IBAction) button4{
     displayField.text=[NSString stringWithFormat:@"%@4",displayField.text];
}
- (IBAction) button5{
     displayField.text=[NSString stringWithFormat:@"%@5",displayField.text];
}
- (IBAction) button6{
    displayField.text=[NSString stringWithFormat:@"%@6",displayField.text];
}
- (IBAction) button7{
     displayField.text=[NSString stringWithFormat:@"%@7",displayField.text];
}
- (IBAction) button8{
    displayField.text=[NSString stringWithFormat:@"%@8",displayField.text];
}
- (IBAction) button9{
     displayField.text=[NSString stringWithFormat:@"%@9",displayField.text];
}

#pragma Actions for operators  +,-,/,*,= button

- (IBAction) plus{
    
    operate = Plus;
    temp = displayField.text;
    displayField.text=@"";

}
- (IBAction) minus{
    operate = Minus;
    temp = displayField.text;
    displayField.text=@"";

}
- (IBAction) multiply{
    operate = Multiply;
    temp = displayField.text;
    displayField.text=@"";
    
}
- (IBAction) divide{
    
    operate = Divide;
    temp = displayField.text;
    displayField.text=@"";
}

- (IBAction) equals {
    NSString *result = displayField.text;
    switch(operate) {
        case Plus :
            displayField.text= [NSString stringWithFormat:@"%qi",[result longLongValue]+[temp longLongValue]];
            share.enabled =YES;
            [self showAlert];
            break;
        case Minus:
            displayField.text= [NSString stringWithFormat:@"%qi",[temp longLongValue]-[result longLongValue]];
            share.enabled =YES;
            [self showAlert];
            break;
        case Divide:
            displayField.text= [NSString stringWithFormat:@"%qi",[temp longLongValue]/[result longLongValue]];
             share.enabled =YES;
            [self showAlert];
            break;
        case Multiply:
            displayField.text= [NSString stringWithFormat:@"%qi",[result longLongValue]*[temp longLongValue]];
            share.enabled =YES;
            [self showAlert];
            break;
    }
}
-(void)showAlert{
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:nil
                          message:@"Now you can share the result"
                          delegate:self
                          cancelButtonTitle:nil
                          otherButtonTitles:@"Ok", nil];
    
    [alert show];
}

#pragma Progress HUD methods
- (void)myProgressTask {
	// This just increases the progress indicator in a loop
	float progress = 1.0f;
	while (progress) {
		progress -= 0.01f;
		HUD.progress = progress;
		usleep(50000);
        if (progress == 0.0f) {
            progress = 1.0f;
        }
	}
}
- (void)dealloacHUD{
	// Remove HUD from screen when the HUD was hidded
	[HUD removeFromSuperview];
 	HUD = nil;
}


#pragma Action  and delegate methods for Sharing the result to facebook.

- (IBAction)myButtonHandlerAction;
{
    HUD.labelText = @"Sharing..";
    
    // myProgressTask uses the HUD instance to update progress
    [HUD showWhileExecuting:@selector(myProgressTask) onTarget:self withObject:nil animated:YES];
     [self.view addSubview:HUD];

    
    if (FBSession.activeSession.isOpen) {
        
         [self promptUserWithAccountNameForStatusUpdate];
        
    } else {
        
        NSArray *permissions = [[NSArray alloc] initWithObjects:
                                @"publish_stream",
                                nil];
        [FBSession openActiveSessionWithPermissions:permissions
                                       allowLoginUI:YES
                                  completionHandler:^(FBSession *session,
                                                      FBSessionState status,
                                                      NSError *error) {
                                      // if login fails for any reason, we alert
                                      if (error) {
                                          
                                          
                                      } else if (FB_ISSESSIONOPENWITHSTATE(status)) {
                                          
                                          [[FBRequest requestForMe] startWithCompletionHandler:
                                           ^(FBRequestConnection *connection, NSDictionary<FBGraphUser> *user, NSError *error) {
                                               if (!error) {
                                                   [self promptUserWithAccountNameForStatusUpdate];

                                               }
                                           }];
                                      }
                                  }];
    }
    
    [FBRequestConnection startForPostStatusUpdate:[NSString stringWithFormat:@"%@",displayField.text] completionHandler:^(FBRequestConnection *connection, id result, NSError *error) {
        if (!error) {
            UIAlertView *tmp = [[UIAlertView alloc]
                                initWithTitle:@"Success"
                                message:@"Status Posted"
                                delegate:self
                                cancelButtonTitle:nil
                                otherButtonTitles:@"Ok", nil];
            
            [tmp show];
            [HUD removeFromSuperViewOnHide];
            [HUD hide:YES];
        } else {
            UIAlertView *tmp = [[UIAlertView alloc]
                                initWithTitle:@"Error"
                                message:@"Some error happened"
                                delegate:self
                                cancelButtonTitle:nil
                                otherButtonTitles:@"Ok", nil];
            
            [tmp show];
            [HUD removeFromSuperViewOnHide];
            [HUD hide:YES];
        }
    }];

    



}

-(void)promptUserWithAccountNameForStatusUpdate {
    [[FBRequest requestForMe] startWithCompletionHandler:
     ^(FBRequestConnection *connection, NSDictionary<FBGraphUser> *user, NSError *error) {
         if (!error) {
             
//             UIAlertView *tmp = [[UIAlertView alloc]
//                                 initWithTitle:@"Publish to FB?"
//                                 message:[NSString stringWithFormat:@"Publish status to ""%@"" Account?", user.name]
//                                 delegate:self
//                                 cancelButtonTitle:nil
//                                 otherButtonTitles:@"No",@"Yes", nil];
//             tmp.tag = 200; // to update status
//             [tmp show];
             
         }
         
     }];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
