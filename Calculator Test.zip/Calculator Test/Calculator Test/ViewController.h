//
//  ViewController.h
//  Calculator Test
//
//  Created by sujith das on 11/07/13.
//  Copyright (c) 2013 Sujith das. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
//#import <Social/Social.h>
typedef enum
{
    Plus,
    Minus,
    Multiply,
    Divide} operation;

@interface ViewController : UIViewController<UIActionSheetDelegate>{
    
    
    IBOutlet UITextField *displayField;
    NSString *temp;
    operation operate;
    IBOutlet UIButton *share;

    MBProgressHUD *HUD;

   }


- (IBAction) button0;
- (IBAction) button1;
- (IBAction) button2;
- (IBAction) button3;
- (IBAction) button4;
- (IBAction) button5;
- (IBAction) button6;
- (IBAction) button7;
- (IBAction) button8;
- (IBAction) button9;
- (IBAction) plus;
- (IBAction) minus;
- (IBAction) multiply;
- (IBAction) divide;
- (IBAction) clearDisplay;
- (IBAction) equals;

@end
